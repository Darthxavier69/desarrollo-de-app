package com.cappucare.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "productos")
data class ProductoEntity(
    @PrimaryKey val id: String,
    val codigo: String,
    val nombre: String,
    val descripcion: String,
    val categoria: String,
    val unidadMedida: String,
    val cantidadDisponible: Int,
    val nivelMinimo: Int,
    val ubicacion: String,
    val estado: String
)